var React = require('react');
var ReactDOM = require('react-dom');


var App = React.createClass({
    render: function () {
        return (
            <div>Welcome to react first program !!</div>
        );
    }
});

ReactDOM.render(<App/>,  document.getElementById("app"));